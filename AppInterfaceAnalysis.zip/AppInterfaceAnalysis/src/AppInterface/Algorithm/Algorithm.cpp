#include "Algorithm.h"


void Algorithm::Init()
{
}

void Algorithm::Start()
{
}